const express = require('express');
const authController = require('./../Controllers/authController');

const { restrictToAdmin } = require('./../Controllers/authController');

const router =express.Router();

// Routes that require admin access



router.route('/signup').post(authController.signup);
router.route('/login').post(authController.login);
// router.route('/resetPass').post(authController.resetPass);
router.route('/forgetPass').post(authController.forgetPass);

module.exports = router;