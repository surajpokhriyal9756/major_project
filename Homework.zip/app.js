const express = require('express');
const http = require('http'); // Require the http module separately
const mongoose = require('mongoose');

const app = express(); // Declare app before using it

const userRouter = require('./Routes/authRouter');
mongoose.connect("mongodb+srv://surajpokhriyal150:an0oe792KCBkYhK4@cluster0.tqahn.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
const User = require('./Models/userModel');

// Create the HTTP server instance
const server = http.createServer(app);

app.use(express.json());
app.use('/users', userRouter);

app.get("/getUsers", (req, res) => {
    User.find({}).then(function (users) {
        res.json(users)
    }).catch(function (err) {
        console.log(err)
    })
})

server.listen(3000, function () {
    console.log('Server is running');
});
