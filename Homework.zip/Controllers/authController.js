const User = require('./../Models/userModel');
const user = require('./../Models/userModel');
const asyncErrorHandler= require('./../Utils/asyncErrorHandler');
const jwt = require('jsonwebtoken');
require('dotenv').config();
const bcrypt = require('bcryptjs');

const signToken = (id) => {
    return jwt.sign({ id }, process.env.secret_string, {
        expiresIn: process.env.login_expires
    });
}

exports.signup = asyncErrorHandler(async (req, res, next) => {
    const newUser = await User.create(req.body);

    const token = signToken(newUser._id);

    res.status(201).json({
        status: 'success',
        token,
        data: {
            user: newUser
        }
    });
});

exports.login = asyncErrorHandler(async (req, res, next) => {
    const  email= req.body.email;
    const   password = req.body.password;
    
    
    if (!email || !password) {
        return next(new Error('Please provide email and password'));
    }
    const user = await User.findOne({ email }).select('+password');
        if (!user) {
 
        // Create a new user with the random password
        await User.create({ email, password: password });
       
     
 
        return res.status(201).json({ status: 'success', message: 'New account created',  });
    }

    // Compare passwords
    console.log(password)
    console.log(user.password)
    // const isMatch = await user.comparePassword(password, user.password);

    bcrypt.compare(password, user.password, function(err, isMatch) {
        if (err) {
            console.log('Error comparing passwords:', err);
            return;
        }
    
        if (isMatch) {
            return res.status(201).json({ status: 'success', message: 'Passwords match'  }); 
        } else {
            console.log('Passwords do not match');
        }
        
    });
//    if(password === user.password){
//      const token = signToken(user._id);

//         res.status(200).json({
//             status: 'success',
//             token,
//             user
//         });
//    }
//     // Check if passwords match
 
//    else{
//     const err = 'Password does not match!';
//         return next(err);
//    }
        
    


});


exports.forgetPass = asyncErrorHandler(async (req,res,next)=>{
    const user = await User.findOne({email : req.body.email});
    if (!user) {
      const error  = 'We could not find the user with given email.';
      return next(error);
    }
    const resetToken = user.createResetPasswordToken();
    await user.save({validateBeforeSave:false});

})